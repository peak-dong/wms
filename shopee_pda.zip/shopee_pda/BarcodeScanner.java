package com.shopee.wms.scanner;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.shopee.wms.utils.LogUtil;
import com.symbol.emdk.EMDKManager;
import com.symbol.emdk.EMDKResults;
import com.symbol.emdk.barcode.BarcodeManager;
import com.symbol.emdk.barcode.ScanDataCollection;
import com.symbol.emdk.barcode.Scanner;
import com.symbol.emdk.barcode.ScannerConfig;
import com.symbol.emdk.barcode.ScannerException;
import com.symbol.emdk.barcode.ScannerResults;
import com.symbol.emdk.barcode.StatusData;

import java.util.ArrayList;

/**
 * Created by QPT678 on 12/10/2018.
 */

public class BarcodeScanner implements EMDKManager.EMDKListener, Scanner.StatusListener, Scanner.DataListener {

    // Declare variables to call interface class
    private static final int I_ON_DATA = 0;
    private static final int I_ON_STATUS = 1;
    private static final int I_ON_ERROR = 2;

    private static EMDKManager emdkManager = null;  // Declare variable to store EMDKManager object
    private static BarcodeManager barcodeManager; // Declare variable to store BarcodeManager object
    private static Scanner scanner = null; //Declare variable to hold scanner device to scann

    private static IOnScannerEvent mUIactivity = null; // Declare scanner event listener for UI activity
    private static Handler mScanHandler; // Handler to call listener
    private static IOnScannerEventRunnable mEventRunnable; // Runnable will be called on mScanHandler
    private static BarcodeScanner mBarcodeScanner; // Declare variable to store BarcodeScanner object

    public final static String TAG = "PDA-BarcodeScanner"; //TAG for logging

    // Entry point - passing context of UI activity
    // Constructor context of BarcodeScanner
    public static BarcodeScanner getInstance(Context context) {
        if (mBarcodeScanner == null) {
            mBarcodeScanner = new BarcodeScanner(context); // call BarcodeScanner() and returns BarcodeScanner object()

        }
        return mBarcodeScanner;
    }

    //get EMDKManager with context of UI activity

    private BarcodeScanner(Context context) {
        // The EMDKManager object will be created and returned in the callback.
        EMDKResults results = EMDKManager.getEMDKManager(context, this);
        // Check the return status of getEMDKManager
        if (results.statusCode != EMDKResults.STATUS_CODE.SUCCESS) {
            LogUtil.e(TAG, "EMDKManager Request Failed");
        }
        // create Handler to move data from Scanner object to an object on the UI thread
        mScanHandler = new Handler(Looper.getMainLooper());
        //create runnable object
        mEventRunnable = new IOnScannerEventRunnable();
    }

    //Method to release the EMDK manager
    public static void releaseEmdk() {
        if (emdkManager != null) {
            emdkManager.release();
            emdkManager = null;
        }
        mBarcodeScanner = null;
    }

    //Function to register BarcodeScanner listener by UI Activity
    //i.e.: com.BarcodeClassSample.Main1Activity@c7b924
    public static void registerUIobject(IOnScannerEvent UIactivity) {
        mUIactivity = UIactivity;
    }

    public static void unregisterUIobject() {
        mUIactivity = null;
    }

    //This method is called automatically whenever the EMDKmanager is initialised
    @Override
    public void onOpened(EMDKManager emdkManager) {
        BarcodeScanner.emdkManager = emdkManager;
        //Method calls to initialize
        initializeScanner();

    }

    //Called when the barcode is scanned
    @Override
    public void onData(ScanDataCollection scanDataCollection) {
        if (scanDataCollection != null
                && scanDataCollection.getResult() == ScannerResults.SUCCESS) {
            ArrayList<ScanDataCollection.ScanData> scanData = scanDataCollection.getScanData();
            if (scanData != null && scanData.size() > 0) {
                final ScanDataCollection.ScanData data = scanData.get(0);
                callIOnScannerEvent(I_ON_DATA, data.getData(), null);
            }
        }
    }

    //Called when the status of the scanner is changed
    //i.e.: com.symbol.emdk.barcode.StatusData@6803045
    @Override
    public void onStatus(StatusData statusData) {
        String statusStr = "";
        StatusData.ScannerStates state = statusData.getState();
        switch (state) {
            case IDLE: //Scanner is IDLE - this is when to request a read
                statusStr = "Scanner enabled and idle";
                try {
                    if (scanner.isEnabled() && !scanner.isReadPending()) {
                        setScannerParameters();
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        scanner.read();
                    }
                } catch (ScannerException e) {
                    LogUtil.e (TAG, "onStatus() - ScannerException " + e.getMessage());
                    e.printStackTrace();
                    statusStr = e.getMessage();
                }
                break;
            case SCANNING: //Scanner is SCANNING
                statusStr = "Scanner beam is on, aim at the barcode";
                break;
            case WAITING: //Scanner is waiting for trigger press
                statusStr = "Waiting for trigger, press to scan barcode";
                break;
            case DISABLED: //Scanner is disabled
                statusStr = "Scanner is not enabled";
                break;
            case ERROR: //Error occurred
                statusStr = "Error occurred during scanning";
                break;
            default:
                break;
        }
        //Return result to populate UI thread
        callIOnScannerEvent(I_ON_STATUS, null, statusStr);
    }

    //Clean up objects created by EMDK manager, if EMDK was closed abruptly.
    @Override
    public void onClosed() {
        if (emdkManager != null) {
            emdkManager.release();
            emdkManager = null;
        }
        mBarcodeScanner = null;

    }

    //Method to initialize, add listeners and enable scanner
    private void initializeScanner() {
        try {
            //Get instance of the Barcode Manager object
            barcodeManager = (BarcodeManager) emdkManager.getInstance(EMDKManager.FEATURE_TYPE.BARCODE);
            //Using the default scanner device to scan barcodes
            scanner = barcodeManager.getDevice(BarcodeManager.DeviceIdentifier.DEFAULT);
            //Add data and status listeners
            scanner.addDataListener(this);
            scanner.addStatusListener(this);

            scanner.enable(); //Enable the scanner

        } catch (ScannerException e) {
            LogUtil.e (TAG, "initializeScanner() - ScannerException " + e.getMessage());
            e.printStackTrace();
        }
        catch (Exception ex) {
            LogUtil.e (TAG,  "initializeScanner() - Exception " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    public static void softTrigger() {
        if (scanner != null) {
            try {
                if (scanner.isReadPending()) {
                    // Cancel the pending read.
                    scanner.cancelRead();
                }
                scanner.triggerType = Scanner.TriggerType.SOFT_ONCE;
                scanner.read();
            } catch (ScannerException e) {
                e.printStackTrace();
            }
        }
    }

    public static void cancelReading(){
        if (scanner != null) {
            try {
                if (scanner.isReadPending()) {
                    scanner.cancelRead();
                }
                scanner.triggerType = Scanner.TriggerType.HARD;
            } catch (ScannerException e) {
                e.printStackTrace();
            }
        }
    }

    //Method to set decoder parameters in the ScannerConfig object
    public void setScannerParameters() {
        try {
            ScannerConfig config = scanner.getConfig();
            config.decoderParams.code128.enabled = true; // enable barcode symbology code128
            config.decoderParams.code39.enabled = true; // enable barcode symbology code39
            config.decoderParams.upca.enabled = true; // enable barcode symbology UPCA
            config.decoderParams.ean13.enabled = true; // enable barcode symbology ean13
            scanner.setConfig(config);
        } catch (ScannerException e) {
            LogUtil.e (TAG, "setScannerParameters() - ScannerException " + e.getMessage());
            e.printStackTrace();
            callIOnScannerEvent(I_ON_ERROR, null, null);
        } catch (RuntimeException e) {
            e.printStackTrace();
            LogUtil.e (TAG, "setScannerParameters() - RuntimeException " + e.getMessage());
            callIOnScannerEvent(I_ON_ERROR, null, null);
        }
    }

    //Method to de-initialize scanner
    public static void deInitScanner() {
        if (scanner != null) {
            try {
                if(scanner.isReadPending()) {
                    scanner.cancelRead();
                }
                scanner.disable();
                scanner.removeDataListener(mBarcodeScanner);
                scanner.removeStatusListener(mBarcodeScanner);
                scanner.release();
            } catch (ScannerException e) {
                LogUtil.e (TAG, "deInitScanner() - ScannerException " + e.getMessage());
                e.printStackTrace();
            }
            scanner = null;
        }

        //Release instance of barcodeManager object
        if (barcodeManager != null) {
            barcodeManager = null;
        }
    }

    private void callIOnScannerEvent(int interfaceId, String data, String status) {
        if (mUIactivity != null) {
            mEventRunnable.setDetails(interfaceId, data, status);
            mScanHandler.post(mEventRunnable);
        }
    }

    private static class IOnScannerEventRunnable implements Runnable {
        private int mInterfaceId = 0;
        private String mBarcodeData = "";
        private String mBarcodeStatus = "";

        public void setDetails(int id, String data, String statusStr) {
            mInterfaceId = id;
            mBarcodeData = data;
            mBarcodeStatus = statusStr;
        }

        @Override
        public void run() {
            if(mUIactivity!=null) {
                switch (mInterfaceId) {
                    case I_ON_DATA:
                        mUIactivity.onDataScanned(mBarcodeData);
                        break;
                    case I_ON_STATUS:
                        mUIactivity.onStatusUpdate(mBarcodeStatus);
                        break;
                    case I_ON_ERROR:
                        mUIactivity.onError();
                        break;
                    default:
                        break;
                }
            }
        }
    }

    public static Scanner getScanner(){
        return BarcodeScanner.scanner;
    }
}
