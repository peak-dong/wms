package com.shopee.wms.ui.activity.inbound;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.shopee.wms.R;
import com.shopee.wms.entity.UnitIdEntity;
import com.shopee.wms.ui.activity.base.BaseScanActivity;
import com.shopee.wms.ui.adapter.UidCollectionAdapter;
import com.shopee.wms.ui.component.TitleBarBuilder;
import com.shopee.wms.ui.component.WrapperLinearLayoutManager;
import com.shopee.wms.ui.view.InfoItemView;
import com.shopee.wms.utils.CommonUtil;
import com.shopee.wms.utils.RegularCheckUtils;
import com.shopee.wms.utils.ToastUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.OnClick;

import static com.shopee.wms.ui.activity.inbound.InboundBasePagingListActivity.EXTRA_INBOUND_DIV;

/**
 * Created by chris on 2018/11/26.
 */
public class InboundUnitIdActivity extends BaseScanActivity {

    @BindView(R.id.rv_content)
    RecyclerView mRvContent;
    @BindView(R.id.iiv_sku_id)
    InfoItemView mIivSkuId;
    @BindView(R.id.iiv_uid_imei)
    InfoItemView mIivUidImei;
    @BindView(R.id.tv_uid_imei)
    TextView mTvUidImei;

    private String mSkuId;
    private int mUidLimit;
    private String mUidRegex;
    private UidCollectionAdapter mUidCollectionAdapter;
    /**
     * receive : 1, putaway: 2
     */
    private int mDivReceiveOrPutaway;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mSkuId = getIntent().getStringExtra(InboundBasePagingListActivity.EXTRA_INBOUND_SKU_ID);
        mUidLimit = getIntent().getIntExtra(InboundBasePagingListActivity.EXTRA_UID_QUANTITY_LIMIT, 0);
        mUidRegex = getIntent().getStringExtra(InboundBasePagingListActivity.EXTRA_INBOUND_UID_REGEX);
        final List<UnitIdEntity> unsubmitUids = (List<UnitIdEntity>)getIntent().getSerializableExtra(InboundBasePagingListActivity.EXTRA_INBOUND_UID_LIST);
        final List<UnitIdEntity> submittedUids = (List<UnitIdEntity>)getIntent().getSerializableExtra(InboundBasePagingListActivity.EXTRA_INBOUND_UNAVAIL_UID_LIST);
        initList();
        initAdapter();
        initListener();
        if (submittedUids != null && submittedUids.size() > 0) {
            Collections.reverse(submittedUids);
            dataSet(submittedUids);
        } else {
            dataSet(unsubmitUids);
        }
    }

    @Override
    public int getContentViewId() {
        return R.layout.activity_receive_uid_sn_imei;
    }

    @Override
    public void initTitleBar(TitleBarBuilder titleBarBuilder) {
        String titleText = "";
        mDivReceiveOrPutaway = getIntent().getIntExtra(EXTRA_INBOUND_DIV, 0);
        switch (mDivReceiveOrPutaway) {
            case 1:
                titleText = getString(R.string.standard_receive);
                break;
            case 2:
                titleText = getString(R.string.standard_putaway);
                break;
            default:
                titleText = getString(R.string.inbound_mgr);
                break;
        }
        titleBarBuilder.setMiddleTitleText(titleText);
    }

    @Override
    public void handleScanResult(String result) {
        if(!RegularCheckUtils.isValid(mUidRegex, result) || TextUtils.isEmpty(result)){
            playErrorSound();
            ToastUtil.showShortToast(R.string.invalid_unit_id);
            return;
        }
        final int size = mUidCollectionAdapter.getData() == null ? 0 : mUidCollectionAdapter.getData().size();
        mIivUidImei.setInfo("");

        if(isDuplicateUid(parseUidList(mUidCollectionAdapter.getData()), result)){
            playErrorSound();
            ToastUtil.showShortToast(R.string.duplicate_uid);
            return;
        }
        if(mUidLimit > 0){
            if (size < mUidLimit) {
                mUidCollectionAdapter.addData(new UnitIdEntity(result, true));
                // Scroll to top
                mRvContent.scrollToPosition(size);
                mTvUidImei.setText("UID/SN/IMEI : " + String.valueOf(size + 1));
            } else {
                playErrorSound();
                ToastUtil.showShortToast(R.string.out_of_range);
            }
        }else {
            mUidCollectionAdapter.addData(new UnitIdEntity(result, true));
            // Scroll to top
            mRvContent.scrollToPosition(size);
            mTvUidImei.setText("UID/SN/IMEI : " + String.valueOf(size + 1));
        }
    }

    @Override
    public void switchToHardType() {

    }

    @Override
    public void switchToSoftOnceType() {

    }

    @Override
    public void switchToSoftAlwaysType() {

    }

    @Override
    public void finish() {
        Intent intent = new Intent();
        intent.putExtra(InboundBasePagingListActivity.EXTRA_INBOUND_UID_LIST,
                (Serializable) mUidCollectionAdapter.getData());
        setResult(-1, intent);
        super.finish();
    }

    @OnClick(R.id.btn_confirm)
    public void onViewClicked() {
        this.finish();
    }

    private void initList() {
        WrapperLinearLayoutManager layoutManager =
                new WrapperLinearLayoutManager(this, LinearLayout.VERTICAL, false);
        layoutManager.setSmoothScrollbarEnabled(true);
        layoutManager.setStackFromEnd(true);
        layoutManager.setReverseLayout(true);
        mRvContent.setLayoutManager(layoutManager);
        mRvContent.setHasFixedSize(true);
        mRvContent.setNestedScrollingEnabled(false);
        mRvContent.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
    }

    private void initAdapter() {
        mUidCollectionAdapter = new UidCollectionAdapter(this);
        mUidCollectionAdapter.openLoadAnimation();
        mRvContent.setAdapter(mUidCollectionAdapter);
        mUidCollectionAdapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {
            @Override
            public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
                mUidCollectionAdapter.remove(position);
                mTvUidImei.setText("UID/SN/IMEI : " +
                        (mUidCollectionAdapter.getData() == null ? 0 : mUidCollectionAdapter.getData().size()));
            }
        });
    }

    private void initListener() {
        mIivUidImei.setScanClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchTriggerType(SOFT_ONECE_TYPE);
            }
        });
        mIivUidImei.setScanEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEND
                        || actionId == EditorInfo.IME_ACTION_DONE
                        || actionId == EditorInfo.IME_ACTION_NEXT
                        || (event != null && KeyEvent.KEYCODE_ENTER == event.getKeyCode()
                        && KeyEvent.ACTION_DOWN == event.getAction())) {
                    if (!TextUtils.isEmpty(mIivUidImei.getInfo())) {
                        handleScanResult(mIivUidImei.getInfo());
                    }
                    CommonUtil.hideSystemInputWhenHasFocus(InboundUnitIdActivity.this);
                }
                return false;
            }
        });
    }

    private void dataSet(List<UnitIdEntity> datas) {
        mUidCollectionAdapter.setNewData(datas);
        mIivSkuId.setInfo(mSkuId);
        mTvUidImei.setText("UID/SN/IMEI : " +
                (mUidCollectionAdapter.getData() == null ? 0 : mUidCollectionAdapter.getData().size()));
    }

    private boolean isDuplicateUid(List<String> unitIds, String uid) {
        if ((unitIds != null) && (!unitIds.isEmpty()) && unitIds.contains(uid)){
            return true;
        }
        return false;
    }

    private List<String> parseUidList(List<UnitIdEntity> unitIdEntityList){
        if(unitIdEntityList == null || unitIdEntityList.isEmpty()){
            return null;
        }
        List<String> uids = new ArrayList<>();
        for(UnitIdEntity unitIdEntity:unitIdEntityList){
            uids.add(unitIdEntity.getUid());
        }
        return uids;
    }
}
