package com.shopee.wms.ui.activity.base;

import android.os.Bundle;
import android.support.annotation.Nullable;

import com.shopee.wms.scanner.BarcodeScanner;
import com.shopee.wms.scanner.IOnScannerEvent;
import com.shopee.wms.utils.LogUtil;
import com.shopee.wms.utils.QrScannerUtils;

/**
 * describe: 扫描页面的基类，外部继承即可使用
 * create_user: weisheng.xu@shopee.com
 * create_date: 2018/7/16
 **/

public abstract class BaseScanActivity extends BaseActivity implements IOnScannerEvent {

    private final static String TAG = BaseScanActivity.class.getName();
    //连续扫描模式
    public static final int SOFT_ALWAYS_TYPE = 0;
    //硬件扫描模式
    public static final int HARD_TYPE = 1;
    //单次扫描模式
    public static final int SOFT_ONECE_TYPE = 2;
    //当前扫描模式
    public int currentTriggerType = 1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onResume() {
        super.onResume();

        BarcodeScanner.getInstance(this);
        BarcodeScanner.registerUIobject(this);
    }

    @Override
    protected void onPause() {
        super.onPause();

        BarcodeScanner.unregisterUIobject();
        BarcodeScanner.deInitScanner();
        BarcodeScanner.releaseEmdk();
    }

    @Override
    public void onDataScanned(String scanData) {
        // 去掉空格
        final String result = scanData.replaceAll(" ", "");
        handleScanResult(result);
    }

    @Override
    public void onStatusUpdate(String scanStatus) {
        LogUtil.v(TAG, "onStatusUpdate - " + scanStatus);
    }

    @Override
    public void onError() {
        LogUtil.e(TAG, "onError() ");
    }

    /**
     * 切换状态
     *
     * @param triggerType
     */
    public void switchTriggerType(int triggerType) {
        switch (triggerType) {
            case HARD_TYPE:
                break;
            case SOFT_ALWAYS_TYPE:
                break;
            case SOFT_ONECE_TYPE:
                BarcodeScanner.softTrigger();
                break;
            default:
                break;
        }
    }

    /**
     * 处理扫描结果
     *
     * @param result
     */
    public abstract void handleScanResult(String result);

    /**
     * 切换到硬件扫描需要做的相关操作
     */
    public void switchToHardType(){}

    /**
     * 切换到软件盘单次扫描需要做的相关操作
     */
    public void switchToSoftOnceType(){}

    /**
     * 切换到软件盘多次扫描需要做的相关操作
     */
    public void switchToSoftAlwaysType(){}

}
